#version 330 core
out vec4 FragColor;

in vec3 ourColor;
in vec2 TexCoord;

 
in vec2 TexCoord2;

// texture sampler
uniformi sampler2D texture1;
uniformi sampler2D texture2;
uniformi sampler2D texture3;

void main()
{
	FragColor = texture(texture1, TexCoord);
}